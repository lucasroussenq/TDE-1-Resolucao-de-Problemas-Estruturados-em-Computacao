package modelo;

public record Point(int x, int y) {}
