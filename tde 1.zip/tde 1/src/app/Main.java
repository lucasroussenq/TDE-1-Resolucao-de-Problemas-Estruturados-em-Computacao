package app;

import modelo.Imagens;
import pinturas.FloodFill;
import pinturas.FloodFillFila;

import java.awt.image.BufferedImage;

public class Main {
    public static void main(String[] args) throws Exception {
        String entrada = "in/mapa.png";
        String saida   = "out/final.png";

        int x = 12, y = 12;       // ponto inicial
        int novaCor = 0xFF0088FF; // azul opaco

        BufferedImage img = Imagens.ler(entrada);

        FloodFill f = new FloodFillFila(); 
        f.preencher(img, x, y, novaCor);

        Imagens.salvar(img, saida);
        System.out.println("ok: " + saida);
    }
}
